import { config } from 'dotenv';
config();

import '@/ai/flows/image-gallery-alt-text-suggestion.ts';